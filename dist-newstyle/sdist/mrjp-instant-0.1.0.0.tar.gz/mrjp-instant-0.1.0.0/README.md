java-11-openjdk

java -jar jasmin.jar -d tmp playground/hello.j 

llvm-as foo.ll
llvm-link -o out.bc foo.bc runtime.bc
lli out.bc